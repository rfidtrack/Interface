<?php
	$path = 'localhost';
	$username = 'root';
	$password = 'RfIdTr@cker';
	$db = 'rfid2';
?>