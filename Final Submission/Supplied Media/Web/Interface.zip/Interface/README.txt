Added in pages for managing tags and reader nodes. Management pages
allow for displaying, adding, editing, and deleting of both tags and
readers. Management pages for tags and readers were linked to the
initial view page. Form posting was used instead of live editing due to
time constraints.
